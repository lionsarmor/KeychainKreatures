# C.3 main-board documentation packet

The purchased ICs/discretes/connectors are covered by the following documents. MCU and screen **chip** datasheets do not establish an exact seller-module schematic, header offset or delivered memory configuration. The SD module uses the supplied seller pinout photo. The exact speaker continuous-power rating remains missing. No document is presented as a substitute for a powered test.

New C.3 selections: [LP0701 manufacturer sheet](https://ww1.microchip.com/downloads/en/DeviceDoc/LP0701-P-Channel-Enhancement-Mode-Lateral-MOSFET-Data-Sheet-20005447A.pdf), [Transcend microSD sheet](https://cdn.transcend-info.com/products/images/modelpic/948/Transcend-USD300S_202404_a2.pdf), [Alpha 3050 wire specification](https://www.alphawire.com/products/wire/hook-up-wire/premium/3050), [Samtec replacement header](https://www.samtec.com/products/tsw-109-07-g-s), [TE insulation sleeve](https://www.te.com/en/product-5052892055.html). No price or availability is guaranteed.

- [esp32-s3.pdf](datasheets/esp32-s3.pdf)
- [mcp23017.pdf](datasheets/mcp23017.pdf)
- [tsal6200.pdf](datasheets/tsal6200.pdf)
- [tsop382.pdf](datasheets/tsop382.pdf)
- [ksp2222a.pdf](datasheets/ksp2222a.pdf)
- [bc327.pdf](datasheets/bc327.pdf)
- [tn0702.pdf](datasheets/tn0702.pdf)
- [lp0701.pdf](datasheets/lp0701.pdf)
- [1n5819.pdf](datasheets/1n5819.pdf)
- [jst-ph.pdf](datasheets/jst-ph.pdf)
- [jst-xh.pdf](datasheets/jst-xh.pdf)
- [mfr-resistors.pdf](datasheets/mfr-resistors.pdf)
- [tda2822.pdf](datasheets/tda2822.pdf)
- [dip-sockets.pdf](datasheets/dip-sockets.pdf)
- [sullins-female-headers.pdf](datasheets/sullins-female-headers.pdf)
- [sullins-order-codes.pdf](datasheets/sullins-order-codes.pdf)
- [nichicon-uvr.pdf](datasheets/nichicon-uvr.pdf)
- [soft-buttons.png](datasheets/soft-buttons.png)
- [motor.pdf](datasheets/motor.pdf)
- [kemet-100nf.pdf](datasheets/kemet-100nf.pdf)
- [kemet-10nf.pdf](datasheets/kemet-10nf.pdf)
- [kemet-1uf.pdf](datasheets/kemet-1uf.pdf)
- [st7789v2-controller.pdf](datasheets/st7789v2-controller.pdf)
- [transcend-usd300s.pdf](datasheets/transcend-usd300s.pdf)
- [tlc5916.pdf](datasheets/tlc5916.pdf)
- [rgb-wp154a4sej3vbdzgw-ca.pdf](datasheets/rgb-wp154a4sej3vbdzgw-ca.pdf)

[Module/speaker evidence limitations](../component_review/MODULE_SOURCE_NOTES.md) · [Per-reference datasheet URLs](C3_BOM_BY_REFERENCE.csv) · [Packet checksum manifest](C3_DATASHEET_MANIFEST.json). Other source URLs remain in the historical documentation index; the C.3 BOM controls population.

C.3 RGB: TLC5916IN PDIP16 with ED16DT socket, Kingbright common-anode LED with formed 2.54 mm lead pitch. See the assembly guide for safe startup and lead forming.
